import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Ng2SearchPipeModule} from 'ng2-search-filter';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { NestedComponent } from './nested/nested.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';

@NgModule({
  declarations: [//components,directives,pipes
    AppComponent, 
    AngularBasicsComponent,
    HomeComponent, 
    TechnologiesComponent,
    AngularPipesComponent,
    RegisterComponent,
    LoginComponent,
    ViewChildComponent,
    NestedComponent,
    CustomDirectivesComponent,
    SpringBootComponent,
    CaseStudyComponent,
    GenderPipe,
    OrderByPipe,
    ParentComponent,
    ChildComponent
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule
  ],
  providers: [],//services
//bootstrap: [AppComponent,HomeComponent,AngularBasicsComponent] //components

  bootstrap: [AppComponent] //components

})
export class AppModule { }
