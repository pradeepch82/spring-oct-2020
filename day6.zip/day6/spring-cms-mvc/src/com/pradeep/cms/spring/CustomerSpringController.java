package com.pradeep.cms.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;

@Controller
@RequestMapping
public class CustomerSpringController {

	

	@Qualifier("mapCustomerServiceImpl")
	@Autowired
	private CustomerService cs;
	
	
	public CustomerSpringController() {
	System.out.println("CustomerSpring Controller Created......");
	}
	

	@RequestMapping(value = "/getcustomers",method = RequestMethod.GET)
	public ModelAndView getAllCustomers() {
			return new ModelAndView("customerList", "customers", cs.findAllCustomers());
	}
	
	@GetMapping("/delete")
	public ModelAndView deleteCustomer(@RequestParam("customerId") int id) {
		     cs.deleteCustomer(id);
		   return new ModelAndView("customerList", "customers", cs.findAllCustomers());
	}
	
	
	@GetMapping("/edit/{customerId}")
	public String editCustomer(@PathVariable("customerId") int id,ModelMap map) {
		
		map.addAttribute("customer", cs.findCustomer(id));
		map.addAttribute("customers", cs.findAllCustomers());
		  
		     return "editCustomer";
	}
	

	@GetMapping("/new")
	public String newCustomer(ModelMap map) {
		map.addAttribute("customer", new Customer());
		map.addAttribute("customers", cs.findAllCustomers());
			
		return "addCustomer";
		}
	
	@PostMapping("/add")
	public ModelAndView addCustomer(@ModelAttribute("customer") Customer customer) {
		   cs.saveCustomer(customer);
		   return new ModelAndView("customerList", "customers", cs.findAllCustomers());
    }
	
	@PostMapping("/update")
	public ModelAndView updateCustomer(@ModelAttribute("customer") Customer customer) {
		   cs.updateCustomer(customer);
		   return new ModelAndView("customerList", "customers", cs.findAllCustomers());
    }
	
	
	
	
}
