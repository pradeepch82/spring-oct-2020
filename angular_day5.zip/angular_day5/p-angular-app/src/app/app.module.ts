import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import {HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { HomeComponent } from './home/home.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { ViewChildComponent } from './view-child/view-child.component';
import { NestedComponent } from './nested/nested.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { FgColorDirective } from './directives/fg-color.directive';
import { BgColorDirective } from './directives/bg-color.directive';
import { ShowDirective } from './directives/show.directive';
import { HideDirective } from './directives/hide.directive';
import { NumberComponent } from './number/number.component';
import { UsersComponent } from './users/users.component';
import { PostsComponent } from './posts/posts.component';
import { TodosComponent } from './todos/todos.component';
import { AlbumsComponent } from './albums/albums.component';
import { PhotosComponent } from './photos/photos.component';
import { CommentsComponent } from './comments/comments.component';
import { UsersListComponent } from './users-list/users-list.component';
import { UsersTableComponent } from './users-table/users-table.component';
import { PostsService } from './services/posts.service';

@NgModule({
  declarations: [//components,directives,pipes
    AppComponent, 
    AngularBasicsComponent,
    HomeComponent, 
    TechnologiesComponent,
    AngularPipesComponent,
    RegisterComponent,
    LoginComponent,
    ViewChildComponent,
    NestedComponent,
    CustomDirectivesComponent,
    SpringBootComponent,
    CaseStudyComponent,
    GenderPipe,
    OrderByPipe,
    ParentComponent,
    ChildComponent,
    FgColorDirective,
    BgColorDirective,
    ShowDirective,
    HideDirective,
    NumberComponent,
    UsersComponent,
    PostsComponent,
    TodosComponent,
    AlbumsComponent,
    PhotosComponent,
    CommentsComponent,
    UsersListComponent,
    UsersTableComponent,
    
  ],
  imports: [ //modules
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    Ng2SearchPipeModule,
    HttpClientModule
    
  ],
  providers: [PostsService],//services
//bootstrap: [AppComponent,HomeComponent,AngularBasicsComponent] //components

  bootstrap: [AppComponent] //components

})
export class AppModule { }
