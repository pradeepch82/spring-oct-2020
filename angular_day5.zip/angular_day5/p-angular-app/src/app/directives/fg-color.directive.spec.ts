import { FgColorDirective } from './fg-color.directive';

describe('FgColorDirective', () => {
  it('should create an instance', () => {
    const directive = new FgColorDirective();
    expect(directive).toBeTruthy();
  });
});
