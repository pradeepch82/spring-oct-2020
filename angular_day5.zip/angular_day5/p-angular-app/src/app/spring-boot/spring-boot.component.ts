import { Component, OnInit } from '@angular/core';
import { CustomersService } from '../services/customers.service';

@Component({
  selector: 'app-spring-boot',
  templateUrl: './spring-boot.component.html',
  styleUrls: ['./spring-boot.component.css']
})
export class SpringBootComponent implements OnInit {


  title="Spring Boot Customer Service Example";

  customers:any;

  customer=null;

  message="";

add=false;
update=false;



  constructor(private cs:CustomersService) {
    console.log("============SpringBootComponent created===============");
   }

  ngOnInit(): void {
    console.log("============SpringBootComponent initialized===============");
    this.getAllCustomers();
  }

  ngOnDestroy(): void {
      console.log("============SpringBootComponent destroyed===============");
   
  }

  newCustomer(){

    this.customer={"customerId":0,
                  "firstName":"",
                  "lastName":"",
                  "gender":"",
                  "email":"",
                  "address":"",
                  "city":"",
                  "state":"",
                  "registrationDate":new Date()}

     this.update=true;
     this.add=false;

    
  }


  getAllCustomers(){
    this.cs.getAllCustomers().subscribe(response=>this.customers=response,error=>this.message=error);
  }

  getCustomerById(customerId:number){
     this.update=false;
     this.add=true;
     
    this.cs.getCustomerById(customerId).subscribe(response=>this.customer=response,error=>this.message=error);
  }

  deleteCustomerById(customerId:number){
    this.cs.deleteCustomerById(customerId).subscribe(response=>this.customers=response,error=>this.message=error);
  }


  updateCustomerById(customerId:number){
    this.cs.updateCustomerById(customerId,this.customer).subscribe(response=>this.customers=response,error=>this.message=error);
   this.customer=null;

  }

  addCustomer(){
    this.cs.addCustomer(this.customer).subscribe(response=>this.customers=response,error=>this.message=error);
    this.customer=null;
   
  }


}
