import { Directive } from '@angular/core';

@Directive({
  selector: '[appC]'
})
export class CDirective {

  constructor() { }

}
