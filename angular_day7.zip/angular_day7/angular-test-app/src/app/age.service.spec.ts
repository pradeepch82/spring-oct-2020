import { TestBed } from '@angular/core/testing';

import { AgeService } from './age.service';

xdescribe('AgeService', () => {
  let service: AgeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true for age with lower boundry :20', () => {
    expect(service.validateAge(20)).toEqual(true);
  });

  it('should return true for age with upper boundry :60', () => {
    expect(service.validateAge(60)).toEqual(true);
  });


  it('should return true for age within boundry :40', () => {
    expect(service.validateAge(40)).toEqual(true);
  });


  it('should return false for age with below lower boundry :11', () => {
    expect(service.validateAge(11)).toEqual(false);
  });

  it('should return false for age with above upper boundry :67', () => {
    expect(service.validateAge(11)).toEqual(false);
  });




});
