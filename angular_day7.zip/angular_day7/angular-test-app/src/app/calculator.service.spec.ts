import { TestBed } from '@angular/core/testing';

import { CalculatorService } from './calculator.service';

describe('CalculatorService', () => {
  let service: CalculatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CalculatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return add(10,5) as 15', () => {
    expect(service.add(10,5)).toEqual(15);
  });
  it('should return sub(10,5) as 5', () => {
    expect(service.sub(10,5)).toEqual(5);
  });
  it('should return mul(10,5) as 50', () => {
    expect(service.mul(10,5)).toEqual(50);
  });
  it('should return div(10,5) as 2', () => {
    expect(service.div(10,5)).toEqual(2);
  });
  it('should return mod(10,5) as 0', () => {
    expect(service.mod(10,5)).toEqual(0);
  });
  




});
