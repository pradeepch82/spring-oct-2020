import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technologies',
  templateUrl: './technologies.component.html',
  styleUrls: ['./technologies.component.css']
})
export class TechnologiesComponent {


  title="Top 5 Technoloiges"; //string

  technologies=[
    {id:101,name:'Spring Boot',likes:0,dislikes:0},
    {id:102,name:'AWS',likes:0,dislikes:0},
    {id:103,name:'Azure',likes:0,dislikes:0},
    {id:104,name:'Data Science',likes:0,dislikes:0},
    {id:105,name:'DevOps',likes:0,dislikes:0},
  ]; //array


  incrementDislikes(t){
    t.dislikes++;
  }

  incrementLikes(t){
    t.likes++;
  }



  
  constructor() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent created   $$$$$$$$$$")
  
   }

  ngOnInit() {

          console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent initialized   $$$$$$$$$$")
  
  }
  
  ngOnDestroy() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent destroyed  $$$$$$$$$$")
   
  }
  
  ngOnChanges() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent ngOnChanges  $$$$$$$$$$")
  }
  
  ngAfterContentInit() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent ngAfterContentInit  $$$$$$$$$$")
  }
  
  ngAfterContentChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent ngAfterContentChecked  $$$$$$$$$$")
  }
  
  ngAfterViewChecked() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent ngAfterViewChecked  $$$$$$$$$$")
  }
  
  ngAfterViewInit() {
    console.log("$$$$$$$$$$$$$$$$$$ TechnologiesComponent ngAfterViewInit  $$$$$$$$$$")
  }

  ngDoCheck() {
    console.log("############ TechnologiesComponent  ngDoCheck #############");
  }
  

}
