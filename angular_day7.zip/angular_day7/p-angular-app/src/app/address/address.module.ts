import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CountryComponent } from './country/country.component';
import { StateComponent } from './state/state.component';
import { CityComponent } from './city/city.component';



@NgModule({
  declarations: [CountryComponent, StateComponent, CityComponent],
  imports: [
    CommonModule
  ]
})
export class AddressModule {

  constructor(){
    console.log("=======AddressModule  created===========");
  }
 }
