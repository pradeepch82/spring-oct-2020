package com.controllers;

import java.security.Principal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class UserController {

	private RestTemplate restTemplate = new RestTemplate();

	@GetMapping("/users")
	public String getAllUsers() {
		return restTemplate.getForObject("https://jsonplaceholder.typicode.com/users", String.class);
	}

	@GetMapping("/hi")
	public String hi() {
		return "Hi";
		
	}
	@GetMapping("/hello")
	public String hello() {
		return "Hello";
		}
	
	@GetMapping("/greet")
	public String greet() {
		return "Greeting";
	}

	@GetMapping("/greeting")
	public String greeting() {
		return "Greeting";
	}
	
	@GetMapping("/helloworld")
	public String helloworld() {
		return "HEllo World";
	}
	
	@GetMapping("/userdetails")
	public Principal user(Principal principal){
		return principal;
	}
	 
	
}
