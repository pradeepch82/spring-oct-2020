package com.atosystel.ems.aop.cc;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.atossyntel.ems.model.Employee;


@Aspect
@Component
public class Logging {

	Logger logger = LoggerFactory.getLogger(Logging.class);


	public Logging() {
		logger.info(" $$$$$$$$$$$ Logging Object created  $$$$$$$$");
	
	}

	
	
	
	
	
	/**
	 * Following is the definition for a pointcut to select * all the methods
	 * available. So advice will be called * for all the methods.
	 */
	@Pointcut("execution(* com.atossyntel.ems.service.EmployeeService.*(..))")
	private void selectAll() {
	}

	
	
	@Pointcut("execution(* com.atossyntel.ems.service.EmployeeService.findEmployee(..))")
	private void select() {
	}

	
	
	
	/**
	 * * This is the method which I would like to execute * before a selected method
	 * execution.
	 */

	
	@Before("selectAll()")
	public void beforeAdvice() {
		logger.info("$$$$$$$$$ Going to setup Employee profile $$$$$$$$$");
	}

	/**
	 * * This is the method which I would like to execute * after a selected method
	 * execution.
	 */
	
	@After("selectAll()")
	public void afterAdvice() {
		logger.info("$$$$$$$$$ Employee profile has been setup $$$$$$$$$$$");
	}

	/**
	 * * This is the method which I would like to execute * when any method returns.
	 */
	
	@AfterReturning(value = "selectAll()",returning = "retVal")
	public void afterReturningAdvice(Object retVal) {
		logger.info(" $$$$$$$$$$ Employee  afterReturning:" + retVal+ " $$$$$$$$$$");
	}

	/**
	 * * This is the method which I would like to execute * if there is an exception
	 * raised by any method.
	 */
	@AfterThrowing(value="selectAll()",throwing ="ex" )
	public void AfterThrowingAdvice(Exception ex) {
		logger.info(" $$$$$$$$$$$$$ Employee There has been an exception: " + ex);
	}

	
	
	@Around("select()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

		Object returnVal = null;
		logger.error(" ##########     In around Advice  ########## ");

		   
		try {
			logger.error("###########  Before Proceed ###########");
			returnVal = joinPoint.proceed();
			logger.error("######## After  Proceed :" + returnVal+"#############");
		    Employee value = (Employee) returnVal;

			value.setFname(value.getFname().toUpperCase());
			value.setLname(value.getLname().toUpperCase());
            returnVal=value;
			
		} catch (Throwable e) {
			e.printStackTrace();
			logger.error(" #########  around Advice  exception wrapped  #########3");

		}
		logger.error(" ########## around Advice  over  ###########");
		return returnVal;
	}

}
