package com.atossyntel.ems.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@EnableWebSecurity
@Configuration
@EnableOAuth2Sso
public class EmsSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private DataSource dataSource;

	/*
	 * @Override protected void configure(AuthenticationManagerBuilder auth) throws
	 * Exception {
	 * 
	 * System.out.
	 * println("##################  In EmsSecurityConfig = configure AuthenticationManagerBuilder auth =========== "
	 * );
	 * 
	 * 
	 * 
	 * auth.inMemoryAuthentication()
	 * .withUser("RAM").password("{noop}RAM").roles("ADMIN").and()
	 * .withUser("RAHIM").password("{noop}RAHIM").roles("STUDENT").and()
	 * .withUser("DAVID").password("{noop}DAVID").roles("TEACHER");
	 * 
	 * 
	 * 
	 * auth.jdbcAuthentication() .passwordEncoder(new BCryptPasswordEncoder())
	 * .dataSource(dataSource);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * //super.configure(auth);
	 * 
	 * 
	 * }
	 */

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	
		http.authorizeRequests()
        .antMatchers("/login").permitAll()
        .anyRequest()
        .authenticated()
        .and()
        .formLogin();
       //.httpBasic();   
	
	}

}
