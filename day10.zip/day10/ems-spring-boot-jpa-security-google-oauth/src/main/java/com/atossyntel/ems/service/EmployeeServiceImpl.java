package com.atossyntel.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atossyntel.ems.dao.EmployeeDao;
import com.atossyntel.ems.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public Employee findEmployee(int employeeId) {
		// TODO Auto-generated method stub
           
		   int a=10/0;
		
		return employeeDao.findById(employeeId).get();
	}

	@Override
	public boolean deleteEmployee(int employeeId) {

		Employee employee = employeeDao.findById(employeeId).get();

		if (employee != null) {

			employeeDao.delete(employee);

			return true;
		}

		return false;

	}

	@Override
	public boolean updateEmployee(Employee employee) {

		return employeeDao.save(employee) == employee;

	}

	@Override
	public boolean saveEmployee(Employee employee) {
		return employeeDao.save(employee) == employee;
		
		
	}

	@Override
	public List<Employee> findAllEmployees() {
		return employeeDao.findAll();

	}

}
