package com;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class demo {

	public static void main(String[] args) {

		BCryptPasswordEncoder b=new BCryptPasswordEncoder();
		
		System.out.println(b.encode("RAM"));
		System.out.println(b.encode("RAHIM"));
		System.out.println(b.encode("DAVID"));
		
		
		
	}

}
