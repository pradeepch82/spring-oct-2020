DROP TABLE IF EXISTS PC_EMPLOYEES;
CREATE TABLE PC_EMPLOYEES (
  employee_id int primary key,
  fname text,
  lname text,
  salary float,
  email text,
  mobile text(10),
  pan text(10),
  doj date
);



