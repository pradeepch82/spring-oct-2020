package com.pradeep.emsspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsSpringBootV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
