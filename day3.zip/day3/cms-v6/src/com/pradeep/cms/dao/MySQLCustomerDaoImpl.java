package com.pradeep.cms.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pradeep.cms.data.CustomerMap;
import com.pradeep.cms.model.Customer;

@Repository("mySQLCustomerDaoImpl")
//@Component
public class MySQLCustomerDaoImpl implements CustomerDao {

	
	private JdbcTemplate jdbcTemplate;
	
	
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	    System.out.println("=========MySQLCustomerDaoImpl setJdbcTemplate method =========");
	}
	
	
	
	
	
	
	
	
	@Autowired
	public MySQLCustomerDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		System.out.println("=========MySQLCustomerDaoImpl param constructor =========");
	
	
	
	}








	public MySQLCustomerDaoImpl() {
	System.out.println("########### MySQLCustomerDaoImpl default constructor created  #########");
	}
	
	
	@Override
	public boolean saveCustomer(Customer customer) {
	
		
		
		return jdbcTemplate.update("insert into customer values(?,?,?,?,?,?,?,?,?)",
				customer.getCustomerId(),
				customer.getFirstName(),
				customer.getLastName(),
				customer.getGender(),
				customer.getEmail(),
				customer.getAddress(),
				customer.getCity(),
				customer.getState(),
				customer.getRegistrationDate())==1;
				
	
	
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		
		return jdbcTemplate.update("update customer set firstName=?,lastName=?,gender=?,email=?,address=?,city=?,state=?,registrationDate=? where customerId=?",
				customer.getFirstName(),
				customer.getLastName(),
				customer.getGender(),
				customer.getEmail(),
				customer.getAddress(),
				customer.getCity(),
				customer.getState(),
				customer.getRegistrationDate(),
				customer.getCustomerId()
				)==1;
		
		
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		return jdbcTemplate.update("delete from customer where customerId=?",customerId)==1;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return jdbcTemplate.queryForObject("select * from customer where customerId=?",new CustomerRowMapper(),customerId);
		
	}

	@Override
	public List<Customer> findAllCustomers() {
		return jdbcTemplate.query("select * from customer", new CustomerRowMapper());
	}

}
