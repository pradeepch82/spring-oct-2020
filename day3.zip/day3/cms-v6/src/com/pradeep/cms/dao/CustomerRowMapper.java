package com.pradeep.cms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pradeep.cms.model.Customer;

public class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int arg1) throws SQLException {
	
		System.out.println("In map Row....");
		
		Customer c=new Customer();
		
		c.setCustomerId(rs.getInt(1));
		c.setFirstName(rs.getString(2));
		c.setLastName(rs.getString(3));
		c.setGender(rs.getString(4));
		c.setEmail(rs.getString(5));
		c.setAddress(rs.getString(6));
		c.setCity(rs.getString(7));
		c.setState(rs.getString(8));
		c.setRegistrationDate(rs.getDate(9));
			
		return c;
	}
	

}
