package com.pradeep.cms.presentation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;

@Controller
//@Component
public class CustomerMainApp {

	@Qualifier("mySQLCustomerServiceImpl")
	@Autowired
	private CustomerService cs;

	public CustomerMainApp() {
		System.out.println("===========CustomerMainApp default constructor created=========");
	}

	/*
	 * // constructor injection public CustomerMainApp(CustomerService cs) {
	 * System.out.
	 * println("===========CustomerMainApp param constructor created=========");
	 * this.cs = cs; }
	 * 
	 * // setter injection public void setCs(CustomerService cs) { this.cs = cs;
	 * System.out.println("===========CustomerMainApp setCs method=========");
	 * 
	 * }
	 */
	public void findCustomer(int customerId) {

		Customer customer = cs.findCustomer(customerId);

		if (customer != null) {
			System.out.println("Customer with id [" + customerId + "] Details\n==================================");
			System.out.println(customer);

		}

		else
			System.out.println("Customer with id [" + customer.getCustomerId() + "] doesn't exist ");

	}

	public void saveCustomer(Customer customer) {
		if (cs.saveCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] Saved successfully ");
		else
			System.out.println("Prblem i saving Customer with id [" + customer.getCustomerId() + "]");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] updated successfully ");
		else
			System.out.println("Customer with id [" + customer.getCustomerId() + "] doesn't exist ");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with id [" + customerId + "] deleted successfully ");
		else
			System.out.println("Customer with id [" + customerId + "] doesn't exist ");

	}

	@PostConstruct
	public void init() {
		System.out.println("============CustomerMain App initialized=============");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("============CustomerMain App going to destroy============");
	}

	public void showAllCustomers() {

		System.out.println("All Customers");
		System.out.println("==============================================================");

		for (Customer c : cs.findAllCustomers())
			System.out.println(c);

	}

	public static void main(String[] args) {

		// create a spring core container
		// XmlBeanFactory c = new XmlBeanFactory(new ClassPathResource("beans.xml"));

		// create a spring advanced container


		
		
		ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans-jdbc.xml");
		
		
		System.out.println("Spring Container created....");

		CustomerMainApp cma = c.getBean(CustomerMainApp.class);

		
		Customer c1=new Customer("Sunil","Gawaskar","Male","Sunil@gmail.com","Warali","Mumbai","Maharashtra");
		Customer c2=new Customer("Roahan","Gawaskar","Male","Rohan@gmail.com","Warali","Mumbai","Maharashtra");
		Customer c3=new Customer("Pradeep","Chinchole","Male","Pradeep@gmail.com","Shivane","Pune","Maharashtra");
		Customer c4=new Customer("Chameli","Raut","Female","Chameli@gmail.com","Washi","Mumbai","Maharashtra");
		Customer c5=new Customer("Ameya","Joshi","Male","Ameya@gmail.com","Dhayri","Pune","Maharashtra");


		cma.showAllCustomers();

		System.out.println("==============================");
		
		
		/*
		 * cma.saveCustomer(c1); cma.saveCustomer(c2); cma.saveCustomer(c3);
		 * cma.saveCustomer(c4); cma.saveCustomer(c5);
		 */
		
		cma.deleteCustomer(13);
		
		System.out.println("==============================");
		
		//cma.showAllCustomers();

		cma.findCustomer(11);
		
		
		c.registerShutdownHook();// stop the container

	}

}
