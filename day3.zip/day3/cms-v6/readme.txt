drop database company;

create database company;

use company;

create table customer(
customerId int primary key,
firstName text,
lastName text,
gender text,
email text,
address text,
city text,
state text,
registrationDate date
);

insert into customer values(11,'Ameya','Joshi','Male','ameya@gmail.com','shivane','pune','mahashtra','2011-11-11');
insert into customer values(12,'Rajesh','Joshi','Male','rajesh@gmail.com','shivane','pune','mahashtra','2011-11-11');
insert into customer values(13,'Sunil','Joshi','Male','sunil@gmail.com','shivane','pune','mahashtra','2011-11-11');

select * from customer;



