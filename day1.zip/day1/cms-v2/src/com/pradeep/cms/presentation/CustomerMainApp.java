package com.pradeep.cms.presentation;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;

public class CustomerMainApp {

	private CustomerService cs;

	public CustomerMainApp() {
		System.out.println("===========CustomerMainApp default constructor created=========");
	}

	// constructor injection
	public CustomerMainApp(CustomerService cs) {
		System.out.println("===========CustomerMainApp param constructor created=========");
		this.cs = cs;
	}

	// setter injection
	public void setCs(CustomerService cs) {
		this.cs = cs;
		System.out.println("===========CustomerMainApp setCs method=========");

	}

	public void findCustomer(int customerId) {

		Customer customer = cs.findCustomer(customerId);

		if (customer != null) {
			System.out.println("Customer with id [" + customerId + "] Details\n==================================");
			System.out.println(customer);

		}

		else
			System.out.println("Customer with id [" + customer.getCustomerId() + "] doesn't exist ");

	}

	public void saveCustomer(Customer customer) {
		if (cs.saveCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] Saved successfully ");
		else
			System.out.println("Prblem i saving Customer with id [" + customer.getCustomerId() + "]");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with id [" + customer.getCustomerId() + "] updated successfully ");
		else
			System.out.println("Customer with id [" + customer.getCustomerId() + "] doesn't exist ");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with id [" + customerId + "] deleted successfully ");
		else
			System.out.println("Customer with id [" + customerId + "] doesn't exist ");

	}
	
	
	
	
	public void init() {
		System.out.println("============CustomerMain App initialized=============");
	}
	
	public void destroy() {
		System.out.println("============CustomerMain App going to destroy============");
	}
	
	
	
	
	

	public void showAllCustomers() {

		System.out.println("All Customers");
		System.out.println("==============================================================");

		for (Customer c : cs.findAllCustomers())
			System.out.println(c);

	}

	public static void main(String[] args) {

		// create a spring core container
		//XmlBeanFactory c = new XmlBeanFactory(new ClassPathResource("beans.xml"));

		// create a spring advanced container
		ClassPathXmlApplicationContext c = new ClassPathXmlApplicationContext("beans.xml");

		System.out.println("Spring Container created....");

		//CustomerMainApp cma=c.getBean(CustomerMainApp.class);
		CustomerMainApp cma1=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma2=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma3=(CustomerMainApp)c.getBean("customerMainApp");
		
		
		System.out.println(cma1);
		System.out.println(cma2);
		System.out.println(cma3);
		
		//cma.showAllCustomers();
		
		
		c.registerShutdownHook();// stop the container
		
	}

}
