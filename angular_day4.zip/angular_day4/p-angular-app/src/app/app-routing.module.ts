import { NgModule, ViewChild } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AngularBasicsComponent } from './angular-basics/angular-basics.component';
import { AngularPipesComponent } from './angular-pipes/angular-pipes.component';
import { CaseStudyComponent } from './case-study/case-study.component';
import { CustomDirectivesComponent } from './custom-directives/custom-directives.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NestedComponent } from './nested/nested.component';
import { RegisterComponent } from './register/register.component';
import { SpringBootComponent } from './spring-boot/spring-boot.component';
import { TechnologiesComponent } from './technologies/technologies.component';
import { ViewChildComponent } from './view-child/view-child.component';

const routes: Routes = [
  {path:'basics',component:AngularBasicsComponent},
  {path:'pipes',component:AngularPipesComponent},
  {path:'technologies',component:TechnologiesComponent},
  {path:'home',component:HomeComponent},
  {path:'nested',component:NestedComponent},
  {path:'view-child',component:ViewChildComponent},
  {path:'case-study',component:CaseStudyComponent},
  {path:'custom-directives',component:CustomDirectivesComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'spring-boot',component:SpringBootComponent},
    

  {path:'**',redirectTo:'home'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
