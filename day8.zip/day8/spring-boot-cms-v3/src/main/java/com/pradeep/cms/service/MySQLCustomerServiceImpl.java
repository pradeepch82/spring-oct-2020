package com.pradeep.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.model.Customer;

@Service
//@Component
public class MySQLCustomerServiceImpl implements CustomerService {

	@Autowired // byType
	private CustomerRepository repository;

	public MySQLCustomerServiceImpl() {
		System.out.println("=======MySQLCustomerServiceImpl constructor created=========");
	}

	/*
	 * public MapCustomerServiceImpl(CustomerDao customerDao) { this.customerDao =
	 * customerDao;
	 * System.out.println("=======MapCustomerServiceImpl param created========="); }
	 * 
	 * public void setCustomerDao(CustomerDao customerDao) { this.customerDao =
	 * customerDao; System.out.
	 * println("=======MapCustomerServiceImpl setCustomerDao executed=========");
	 * 
	 * }
	 * 
	 */ @Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return repository.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		Customer c = repository.findById(customer.getCustomerId()).get();

		if (c != null)
			return repository.save(customer) == customer;

		return false;

	}

	@Override
	public boolean deleteCustomer(int customerId) {

		Customer c = repository.findById(customerId).get();

		if (c != null)
		{
			repository.delete(c);
			return true;
		}
			return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		
		return repository.findById(customerId).get();
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
