import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscriber } from 'rxjs';

@Component({
  selector: 'app-angular-basics',
  templateUrl: './angular-basics.component.html',
  styleUrls: ['./angular-basics.component.css']
})
export class AngularBasicsComponent implements OnInit,OnDestroy {


  title='Angular Basics'; //string

  colors=['RED','GREEN','BLUE','MAGENTA'];// array

  day=1;   //number
  min:number=1;//number
  max=8;//number


  hide:boolean=false; //boolean
  show=true;//boolean

 employee={
   id:101,
   name:'Pradeep chinchole',
   salary:124000.43422244,
   variable:0.12,
   pan:'amood9845D',
   mobile:'9158765252',
   doj:new Date()
 }

 showHide(){
   this.hide=!this.hide;
 }


time=new Observable<string>((s:Subscriber<string>)=>{
  setInterval(()=>{
    s.next(new Date().toLocaleString());
    },1000);
});

















  constructor() {
    console.log("============AngularBasicsComponent created===============");

   }

  ngOnInit(): void {
    console.log("============AngularBasicsComponent initialized===============");
    
  }

  ngOnDestroy(): void {
      console.log("============AngularBasicsComponent destroyed===============");
   
  }
  
}
