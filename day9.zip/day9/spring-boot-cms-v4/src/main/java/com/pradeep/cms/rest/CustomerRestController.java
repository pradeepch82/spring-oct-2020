package com.pradeep.cms.rest;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.cms.model.Customer;
import com.pradeep.cms.service.CustomerService;

@RestController
@RequestMapping("/rest")
public class CustomerRestController {

	@Autowired
	private CustomerService cs;

	public CustomerRestController() {
		System.out.println("===========CustomerRestController default constructor created=========");
	}


	@PostConstruct
	public void init() {
		System.out.println("============CustomerRestController App initialized=============");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("============CustomerRestController App going to destroy============");
	}

	@GetMapping("/customers")
	public List<Customer> getAllCustomers() {
		return cs.findAllCustomers();
	}

	@GetMapping("/customers/{id}")
	public Customer getCustomerById(@PathVariable("id") int customerId) {
		return cs.findCustomer(customerId);
	}

	@DeleteMapping("/customers/{id}")
	public List<Customer> deleteCustomerById(@PathVariable("id") int customerId) {
		cs.deleteCustomer(customerId);
		return cs.findAllCustomers();
	}

	@PutMapping("/customers/{id}")
	public List<Customer> updateCustomerById(@PathVariable("id") int customerId,@RequestBody Customer customer) {
		cs.updateCustomer(customer);
		return cs.findAllCustomers();
	}
	

	@PostMapping("/customers")
	public List<Customer> addCustomer(@RequestBody Customer customer) {
		cs.saveCustomer(customer);
		
		return cs.findAllCustomers();
	}
	

	
}
