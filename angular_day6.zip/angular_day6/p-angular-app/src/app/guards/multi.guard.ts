import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MultiGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {
 


  constructor(private router:Router){
console.log("=============== MultiGuard  Service created...")
  }


  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
      var email=sessionStorage.getItem("email");
      
      if(email==null || email ==undefined)
      {
        alert("Please Login first");
        this.router.navigate(['/login']);
        return false;
      }
      return true;
  }
 
  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      var email=sessionStorage.getItem("email");
      
      if(email!='pradeep@gmail.com')
      {
        alert("You are not authorized to access this section,Try with other credentials");
        this.router.navigate(['/login']);
        return false;
      }
      return true; 
    }
 
  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    
      return confirm("Do you want leave this route?");


  }
 
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      return confirm("Do you want load this address module?");
  }
}
