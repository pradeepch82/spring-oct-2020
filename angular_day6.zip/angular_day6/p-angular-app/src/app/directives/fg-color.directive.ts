import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[fgColor]'
})
export class FgColorDirective {

  constructor(private el:ElementRef,private r:Renderer2) {
    console.log("=========FgColorDirective  created=============");
   }


   @Input() 
   set fgColor(value:string){
     console.log("In setFgColor  :"+value);
     this.r.setStyle(this.el.nativeElement,"color",value);
   }

}
