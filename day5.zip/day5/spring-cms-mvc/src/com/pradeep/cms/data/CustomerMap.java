package com.pradeep.cms.data;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.cms.model.Customer;

public enum CustomerMap {
INSTANCE;
	

	private Map<Integer, Customer> map;
	
	
private CustomerMap() {
	map=new HashMap<>();
	
	Customer c1=new Customer("Sunil","Gawaskar","Male","Sunil@gmail.com","Warali","Mumbai","Maharashtra");
	Customer c2=new Customer("Roahan","Gawaskar","Male","Rohan@gmail.com","Warali","Mumbai","Maharashtra");
	Customer c3=new Customer("Pradeep","Chinchole","Male","Pradeep@gmail.com","Shivane","Pune","Maharashtra");
	Customer c4=new Customer("Chameli","Raut","Female","Chameli@gmail.com","Washi","Mumbai","Maharashtra");
	Customer c5=new Customer("Ameya","Joshi","Male","Ameya@gmail.com","Dhayri","Pune","Maharashtra");

	map.put(c1.getCustomerId(), c1);
	map.put(c2.getCustomerId(), c2);
	map.put(c3.getCustomerId(), c3);
	map.put(c4.getCustomerId(), c4);
	map.put(c5.getCustomerId(), c5);
	
	
}	

public Map<Integer, Customer> getMap() {
	return map;
}

	
	
}
